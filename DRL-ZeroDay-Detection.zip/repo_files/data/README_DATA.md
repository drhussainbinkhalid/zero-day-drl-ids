# Datasets and Splits

This document describes how to obtain and preprocess the datasets used in our paper:
**"Machine Learning-Based Zero-Day Attack Detection Using Deep Reinforcement Learning"**

---

## Datasets Overview

| Dataset | Samples | Features | Attack Types | Source |
|---------|---------|----------|--------------|--------|
| NSL-KDD | 148,517 | 41 | 4 categories | [UNB](https://www.unb.ca/cic/datasets/nsl.html) |
| CICIDS2017 | 2,830,743 | 78 | 14 types | [UNB](https://www.unb.ca/cic/datasets/ids-2017.html) |
| CIC-AndMal2017 | 10,854 | 80 | 4 categories | [UNB](https://www.unb.ca/cic/datasets/andmal2017.html) |
| Custom Zero-Day | 350,000 | 65 | Simulated CVEs | This work |

---

## 1. Download Raw Data

### NSL-KDD
```bash
cd data/raw
wget https://www.unb.ca/cic/datasets/nsl.html -O nsl_kdd.zip
unzip nsl_kdd.zip -d nsl_kdd/
```

### CICIDS2017
```bash
cd data/raw
# Download from: https://www.unb.ca/cic/datasets/ids-2017.html
# Files: Monday-WorkingHours.pcap_ISCX.csv through Friday-WorkingHours.pcap_ISCX.csv
mkdir cicids2017
# Place all CSV files in data/raw/cicids2017/
```

### CIC-AndMal2017
```bash
cd data/raw
# Download from: https://www.unb.ca/cic/datasets/andmal2017.html
mkdir cicandmal2017
# Place CSV files in data/raw/cicandmal2017/
```

### Custom Zero-Day Dataset
The custom zero-day dataset is provided in this repository:
```
data/splits/custom_zd/
├── train.csv
├── val.csv
└── test_zero_day.csv
```

---

## 2. Preprocessing

Run the preprocessing scripts to create attack-family-aware splits:

```bash
# Preprocess all datasets
python -m src.data_utils.preprocess_nsl_kdd
python -m src.data_utils.preprocess_cicids2017
python -m src.data_utils.preprocess_cicandmal2017

# Or run all at once
python -m src.data_utils.preprocess_all
```

### What preprocessing does:
1. **Cleaning**: Remove duplicates, handle missing values
2. **Normalization**: Min-max scaling to [0, 1]
3. **Feature Selection**: PCA + Information Gain (30 features)
4. **Attack-Family-Aware Splitting**: Ensures zero-day simulation

---

## 3. Attack Family Splits (Zero-Day Simulation)

**Critical for reproducibility**: We use attack-family-aware splits to prevent data leakage.

### NSL-KDD
| Split | Attack Families |
|-------|-----------------|
| Train/Val | DoS (neptune, smurf, pod), Probe (portsweep, satan) |
| Test (Zero-Day) | R2L (warezclient, warezmaster), U2R (buffer_overflow, rootkit) |

### CICIDS2017
| Split | Attack Families |
|-------|-----------------|
| Train/Val | DoS (Hulk, GoldenEye), DDoS, Port Scan, Brute Force |
| Test (Zero-Day) | Web Attacks (XSS, SQL Injection), Botnet, Infiltration, Heartbleed |

### CIC-AndMal2017
| Split | Attack Families |
|-------|-----------------|
| Train/Val | Adware, Ransomware, SMS Malware |
| Test (Zero-Day) | Scareware, Backdoor, Bankbot |

---

## 4. Output Structure

After preprocessing, the data structure will be:

```
data/
├── raw/                          # Original downloaded data
│   ├── nsl_kdd/
│   ├── cicids2017/
│   └── cicandmal2017/
├── splits/                       # Preprocessed splits (ready for training)
│   ├── nsl_kdd/
│   │   ├── train.csv
│   │   ├── val.csv
│   │   ├── test_zero_day.csv
│   │   └── feature_names.json
│   ├── cicids2017/
│   │   ├── train.csv
│   │   ├── val.csv
│   │   ├── test_zero_day.csv
│   │   └── feature_names.json
│   ├── cicandmal2017/
│   │   └── ...
│   └── custom_zd/
│       └── ...
└── README_DATA.md
```

---

## 5. Verification

To verify your splits match ours:

```bash
python -m src.data_utils.verify_splits
```

Expected output:
```
NSL-KDD:
  Train: 41,214 normal + 38,892 attack
  Val: 13,738 normal + 12,964 attack  
  Test (ZD): 29,703 samples
  
CICIDS2017:
  Train: 1,245,312 normal + 298,445 attack
  Val: 415,104 normal + 99,482 attack
  Test (ZD): 566,149 samples
```

---

## 6. License

- NSL-KDD, CICIDS2017, CIC-AndMal2017: Please cite the original sources
- Custom Zero-Day Dataset: CC BY 4.0 (cite this paper)

---

## Citation

If you use these datasets with our preprocessing, please cite:

```bibtex
@article{yourname2024zerodaydrl,
  title={Machine Learning-Based Zero-Day Attack Detection Using Deep Reinforcement Learning},
  author={Your Name},
  journal={Information Security Journal},
  year={2024}
}
```
