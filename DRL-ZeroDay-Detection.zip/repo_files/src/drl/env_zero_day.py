"""
Zero-Day Attack Detection Environment for Deep Reinforcement Learning

This module implements a Gymnasium-compatible environment for training
DRL agents on intrusion detection with asymmetric reward functions.
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Tuple, Dict, Any, Optional


class ZeroDayDetectionEnv(gym.Env):
    """
    Custom Gym environment for zero-day attack detection.
    
    State: Feature vector of a network flow (normalized)
    Action: 0 = Normal, 1 = Attack
    Reward: Asymmetric reward function favoring attack detection
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix (n_samples, n_features)
    y : np.ndarray
        Labels (0 = normal, 1 = attack)
    fn_penalty : float
        Penalty for false negatives (missed attacks), default=-10
    fp_penalty : float
        Penalty for false positives, default=-1
    correct_reward : float
        Reward for correct classification, default=+1
    shuffle : bool
        Whether to shuffle data each episode
    """
    
    metadata = {"render_modes": ["human"]}
    
    def __init__(
        self,
        X: np.ndarray,
        y: np.ndarray,
        fn_penalty: float = -10.0,
        fp_penalty: float = -1.0,
        correct_reward: float = 1.0,
        shuffle: bool = True,
        seed: Optional[int] = None
    ):
        super().__init__()
        
        self.X = np.array(X, dtype=np.float32)
        self.y = np.array(y, dtype=np.int32)
        self.n_samples = len(self.X)
        self.n_features = self.X.shape[1]
        
        # Reward parameters (asymmetric)
        self.fn_penalty = fn_penalty  # λ in paper (default: -10)
        self.fp_penalty = fp_penalty
        self.correct_reward = correct_reward
        
        self.shuffle = shuffle
        self.rng = np.random.default_rng(seed)
        
        # Gym spaces
        self.observation_space = spaces.Box(
            low=0.0, high=1.0, shape=(self.n_features,), dtype=np.float32
        )
        self.action_space = spaces.Discrete(2)  # 0: Normal, 1: Attack
        
        # Episode state
        self.current_idx = 0
        self.indices = np.arange(self.n_samples)
        
        # Metrics tracking
        self.episode_metrics = self._init_metrics()
    
    def _init_metrics(self) -> Dict[str, int]:
        return {
            "tp": 0, "tn": 0, "fp": 0, "fn": 0,
            "total_reward": 0.0
        }
    
    def reset(
        self, 
        seed: Optional[int] = None, 
        options: Optional[Dict] = None
    ) -> Tuple[np.ndarray, Dict[str, Any]]:
        """Reset environment for new episode."""
        super().reset(seed=seed)
        
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        
        if self.shuffle:
            self.rng.shuffle(self.indices)
        
        self.current_idx = 0
        self.episode_metrics = self._init_metrics()
        
        obs = self.X[self.indices[self.current_idx]]
        info = {"true_label": int(self.y[self.indices[self.current_idx]])}
        
        return obs, info
    
    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict[str, Any]]:
        """
        Execute one step in the environment.
        
        Parameters
        ----------
        action : int
            0 = classify as normal, 1 = classify as attack
            
        Returns
        -------
        observation : np.ndarray
            Next state (feature vector)
        reward : float
            Reward based on asymmetric function
        terminated : bool
            True if episode ended (all samples processed)
        truncated : bool
            Always False (no truncation)
        info : dict
            Additional information (metrics)
        """
        true_label = self.y[self.indices[self.current_idx]]
        
        # Compute reward using asymmetric function
        reward = self._compute_reward(action, true_label)
        
        # Update metrics
        self._update_metrics(action, true_label, reward)
        
        # Move to next sample
        self.current_idx += 1
        terminated = self.current_idx >= self.n_samples
        
        # Get next observation
        if not terminated:
            obs = self.X[self.indices[self.current_idx]]
            next_label = int(self.y[self.indices[self.current_idx]])
        else:
            obs = np.zeros(self.n_features, dtype=np.float32)
            next_label = -1
        
        info = {
            "true_label": next_label,
            "metrics": self.episode_metrics.copy()
        }
        
        return obs, reward, terminated, False, info
    
    def _compute_reward(self, action: int, true_label: int) -> float:
        """
        Compute asymmetric reward.
        
        R(s, a) = 
            +1  if correct classification
            -1  if false positive (normal classified as attack)
            -λ  if false negative (attack classified as normal), λ=10
        """
        if action == true_label:
            return self.correct_reward
        elif action == 0 and true_label == 1:
            # False negative: missed attack (most severe)
            return self.fn_penalty
        else:
            # False positive: false alarm
            return self.fp_penalty
    
    def _update_metrics(self, action: int, true_label: int, reward: float):
        """Update episode metrics."""
        if action == 1 and true_label == 1:
            self.episode_metrics["tp"] += 1
        elif action == 0 and true_label == 0:
            self.episode_metrics["tn"] += 1
        elif action == 1 and true_label == 0:
            self.episode_metrics["fp"] += 1
        else:
            self.episode_metrics["fn"] += 1
        
        self.episode_metrics["total_reward"] += reward
    
    def get_episode_summary(self) -> Dict[str, float]:
        """Get summary metrics for the episode."""
        m = self.episode_metrics
        total = m["tp"] + m["tn"] + m["fp"] + m["fn"]
        
        accuracy = (m["tp"] + m["tn"]) / total if total > 0 else 0
        precision = m["tp"] / (m["tp"] + m["fp"]) if (m["tp"] + m["fp"]) > 0 else 0
        recall = m["tp"] / (m["tp"] + m["fn"]) if (m["tp"] + m["fn"]) > 0 else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
        
        return {
            "accuracy": accuracy,
            "precision": precision,
            "recall": recall,
            "f1": f1,
            "total_reward": m["total_reward"],
            "fp_rate": m["fp"] / (m["fp"] + m["tn"]) if (m["fp"] + m["tn"]) > 0 else 0
        }


def create_env(
    X: np.ndarray,
    y: np.ndarray,
    lambda_fn: float = 10.0,
    seed: Optional[int] = None
) -> ZeroDayDetectionEnv:
    """
    Factory function to create environment with paper's default settings.
    
    Parameters
    ----------
    X : np.ndarray
        Feature matrix
    y : np.ndarray
        Labels
    lambda_fn : float
        False negative penalty (λ in paper), default=10
    seed : int, optional
        Random seed
    """
    return ZeroDayDetectionEnv(
        X=X,
        y=y,
        fn_penalty=-lambda_fn,
        fp_penalty=-1.0,
        correct_reward=1.0,
        shuffle=True,
        seed=seed
    )


if __name__ == "__main__":
    # Quick test
    X_test = np.random.rand(100, 30).astype(np.float32)
    y_test = np.random.randint(0, 2, 100)
    
    env = create_env(X_test, y_test, lambda_fn=10.0, seed=42)
    obs, info = env.reset()
    
    print(f"Observation shape: {obs.shape}")
    print(f"Action space: {env.action_space}")
    
    total_reward = 0
    done = False
    while not done:
        action = env.action_space.sample()
        obs, reward, done, _, info = env.step(action)
        total_reward += reward
    
    summary = env.get_episode_summary()
    print(f"Episode summary: {summary}")
