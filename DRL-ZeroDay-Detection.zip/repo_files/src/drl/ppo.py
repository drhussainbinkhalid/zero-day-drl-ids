"""
Proximal Policy Optimization (PPO) for Zero-Day Attack Detection

Implementation based on:
- Schulman et al. (2017) "Proximal Policy Optimization Algorithms"
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Tuple, Dict, List, Optional


class ActorCritic(nn.Module):
    """Actor-Critic network for PPO."""
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_sizes: Tuple[int, ...] = (256, 256, 128)
    ):
        super().__init__()
        
        # Shared feature extractor
        layers = []
        prev_size = state_dim
        for hidden_size in hidden_sizes[:-1]:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
            ])
            prev_size = hidden_size
        
        self.shared = nn.Sequential(*layers)
        
        # Actor head (policy)
        self.actor = nn.Sequential(
            nn.Linear(prev_size, hidden_sizes[-1]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[-1], action_dim),
            nn.Softmax(dim=-1)
        )
        
        # Critic head (value function)
        self.critic = nn.Sequential(
            nn.Linear(prev_size, hidden_sizes[-1]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[-1], 1)
        )
        
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        features = self.shared(x)
        action_probs = self.actor(features)
        value = self.critic(features)
        return action_probs, value
    
    def get_action(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        action_probs, value = self.forward(x)
        dist = torch.distributions.Categorical(action_probs)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        return action, log_prob, value


class RolloutBuffer:
    """Buffer for storing trajectories."""
    
    def __init__(self):
        self.states = []
        self.actions = []
        self.rewards = []
        self.values = []
        self.log_probs = []
        self.dones = []
    
    def add(self, state, action, reward, value, log_prob, done):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.values.append(value)
        self.log_probs.append(log_prob)
        self.dones.append(done)
    
    def clear(self):
        self.states = []
        self.actions = []
        self.rewards = []
        self.values = []
        self.log_probs = []
        self.dones = []
    
    def compute_returns_advantages(
        self,
        last_value: float,
        gamma: float = 0.99,
        gae_lambda: float = 0.95
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Compute returns and GAE advantages."""
        rewards = np.array(self.rewards)
        values = np.array(self.values + [last_value])
        dones = np.array(self.dones + [False])
        
        # GAE computation
        advantages = np.zeros_like(rewards)
        last_gae = 0
        
        for t in reversed(range(len(rewards))):
            delta = rewards[t] + gamma * values[t + 1] * (1 - dones[t]) - values[t]
            advantages[t] = last_gae = delta + gamma * gae_lambda * (1 - dones[t]) * last_gae
        
        returns = advantages + values[:-1]
        
        return returns, advantages
    
    def get_batches(
        self,
        returns: np.ndarray,
        advantages: np.ndarray,
        batch_size: int
    ):
        """Generate mini-batches for training."""
        n_samples = len(self.states)
        indices = np.random.permutation(n_samples)
        
        for start in range(0, n_samples, batch_size):
            end = start + batch_size
            batch_indices = indices[start:end]
            
            yield (
                np.array([self.states[i] for i in batch_indices]),
                np.array([self.actions[i] for i in batch_indices]),
                np.array([self.log_probs[i] for i in batch_indices]),
                returns[batch_indices],
                advantages[batch_indices]
            )


class PPOAgent:
    """
    PPO Agent for zero-day attack detection.
    
    Parameters
    ----------
    state_dim : int
        Dimension of state space
    action_dim : int
        Number of actions
    hidden_sizes : tuple
        Hidden layer sizes
    lr : float
        Learning rate
    gamma : float
        Discount factor
    gae_lambda : float
        GAE lambda
    clip_epsilon : float
        PPO clipping parameter
    value_coef : float
        Value loss coefficient
    entropy_coef : float
        Entropy bonus coefficient
    max_grad_norm : float
        Gradient clipping threshold
    n_epochs : int
        Number of optimization epochs per update
    batch_size : int
        Mini-batch size
    device : str
        'cuda' or 'cpu'
    """
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int = 2,
        hidden_sizes: Tuple[int, ...] = (256, 256, 128),
        lr: float = 3e-4,
        gamma: float = 0.99,
        gae_lambda: float = 0.95,
        clip_epsilon: float = 0.2,
        value_coef: float = 0.5,
        entropy_coef: float = 0.01,
        max_grad_norm: float = 0.5,
        n_epochs: int = 10,
        batch_size: int = 64,
        device: str = "cuda" if torch.cuda.is_available() else "cpu"
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.clip_epsilon = clip_epsilon
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.max_grad_norm = max_grad_norm
        self.n_epochs = n_epochs
        self.batch_size = batch_size
        self.device = torch.device(device)
        
        # Network
        self.policy = ActorCritic(state_dim, action_dim, hidden_sizes).to(self.device)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr, eps=1e-5)
        
        # Rollout buffer
        self.buffer = RolloutBuffer()
        
        # Training stats
        self.training_stats = []
    
    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, float, float]:
        """Select action and return action, log_prob, value."""
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action, log_prob, value = self.policy.get_action(state_tensor)
        
        return action.item(), log_prob.item(), value.item()
    
    def store_transition(self, state, action, reward, value, log_prob, done):
        """Store transition in rollout buffer."""
        self.buffer.add(state, action, reward, value, log_prob, done)
    
    def train(self, last_value: float = 0.0) -> Dict[str, float]:
        """Perform PPO update."""
        # Compute returns and advantages
        returns, advantages = self.buffer.compute_returns_advantages(
            last_value, self.gamma, self.gae_lambda
        )
        
        # Normalize advantages
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)
        
        # Training loop
        total_policy_loss = 0
        total_value_loss = 0
        total_entropy = 0
        n_updates = 0
        
        for _ in range(self.n_epochs):
            for batch in self.buffer.get_batches(returns, advantages, self.batch_size):
                states, actions, old_log_probs, batch_returns, batch_advantages = batch
                
                states = torch.FloatTensor(states).to(self.device)
                actions = torch.LongTensor(actions).to(self.device)
                old_log_probs = torch.FloatTensor(old_log_probs).to(self.device)
                batch_returns = torch.FloatTensor(batch_returns).to(self.device)
                batch_advantages = torch.FloatTensor(batch_advantages).to(self.device)
                
                # Get current policy outputs
                action_probs, values = self.policy(states)
                values = values.squeeze()
                
                dist = torch.distributions.Categorical(action_probs)
                new_log_probs = dist.log_prob(actions)
                entropy = dist.entropy().mean()
                
                # PPO clipped objective
                ratio = torch.exp(new_log_probs - old_log_probs)
                surr1 = ratio * batch_advantages
                surr2 = torch.clamp(ratio, 1 - self.clip_epsilon, 1 + self.clip_epsilon) * batch_advantages
                policy_loss = -torch.min(surr1, surr2).mean()
                
                # Value loss
                value_loss = nn.MSELoss()(values, batch_returns)
                
                # Total loss
                loss = policy_loss + self.value_coef * value_loss - self.entropy_coef * entropy
                
                # Optimize
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.policy.parameters(), self.max_grad_norm)
                self.optimizer.step()
                
                total_policy_loss += policy_loss.item()
                total_value_loss += value_loss.item()
                total_entropy += entropy.item()
                n_updates += 1
        
        # Clear buffer
        self.buffer.clear()
        
        stats = {
            "policy_loss": total_policy_loss / n_updates,
            "value_loss": total_value_loss / n_updates,
            "entropy": total_entropy / n_updates
        }
        self.training_stats.append(stats)
        
        return stats
    
    def save(self, path: str):
        """Save model checkpoint."""
        torch.save({
            'policy_state_dict': self.policy.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)
    
    def load(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.policy.load_state_dict(checkpoint['policy_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    def predict(self, states: np.ndarray) -> np.ndarray:
        """Batch prediction for evaluation."""
        self.policy.eval()
        with torch.no_grad():
            states_tensor = torch.FloatTensor(states).to(self.device)
            action_probs, _ = self.policy(states_tensor)
            actions = action_probs.argmax(dim=1).cpu().numpy()
        self.policy.train()
        return actions
    
    def predict_proba(self, states: np.ndarray) -> np.ndarray:
        """Get action probabilities."""
        self.policy.eval()
        with torch.no_grad():
            states_tensor = torch.FloatTensor(states).to(self.device)
            action_probs, _ = self.policy(states_tensor)
            probs = action_probs.cpu().numpy()
        self.policy.train()
        return probs


if __name__ == "__main__":
    # Quick test
    agent = PPOAgent(state_dim=30, action_dim=2)
    
    # Simulate rollout
    for _ in range(256):
        state = np.random.rand(30).astype(np.float32)
        action, log_prob, value = agent.select_action(state)
        reward = np.random.choice([-10, -1, 1])
        done = np.random.random() < 0.01
        
        agent.store_transition(state, action, reward, value, log_prob, done)
    
    # Train
    stats = agent.train(last_value=0.0)
    print(f"Training stats: {stats}")
