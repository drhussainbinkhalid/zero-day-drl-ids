"""
Training Script for DRL-based Zero-Day Attack Detection

Usage:
    python -m src.drl.train_drl --config configs/ppo_cicids2017.yaml
    python -m src.drl.train_drl --model ppo --dataset cicids2017 --lambda_fn 10
"""

import argparse
import yaml
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
from tqdm import tqdm
import json

from src.drl.env_zero_day import create_env
from src.drl.dqn import DQNAgent
from src.drl.ppo import PPOAgent
from src.drl.a2c import A2CAgent
from src.evaluation.metrics import compute_metrics


def load_data(dataset: str, data_dir: str = "data/splits") -> dict:
    """Load train/val/test splits."""
    path = Path(data_dir) / dataset
    
    train_df = pd.read_csv(path / "train.csv")
    val_df = pd.read_csv(path / "val.csv")
    test_df = pd.read_csv(path / "test_zero_day.csv")
    
    # Assume last column is label
    X_train = train_df.iloc[:, :-1].values.astype(np.float32)
    y_train = train_df.iloc[:, -1].values.astype(np.int32)
    
    X_val = val_df.iloc[:, :-1].values.astype(np.float32)
    y_val = val_df.iloc[:, -1].values.astype(np.int32)
    
    X_test = test_df.iloc[:, :-1].values.astype(np.float32)
    y_test = test_df.iloc[:, -1].values.astype(np.int32)
    
    return {
        "train": (X_train, y_train),
        "val": (X_val, y_val),
        "test": (X_test, y_test)
    }


def create_agent(model_name: str, state_dim: int, config: dict):
    """Create DRL agent based on model name."""
    if model_name.lower() == "dqn":
        return DQNAgent(
            state_dim=state_dim,
            action_dim=2,
            hidden_sizes=tuple(config.get("hidden_sizes", [256, 256, 128])),
            lr=config.get("learning_rate", 1e-3),
            gamma=config.get("gamma", 0.99),
            batch_size=config.get("batch_size", 64)
        )
    elif model_name.lower() == "ppo":
        return PPOAgent(
            state_dim=state_dim,
            action_dim=2,
            hidden_sizes=tuple(config.get("hidden_sizes", [256, 256, 128])),
            lr=config.get("learning_rate", 3e-4),
            gamma=config.get("gamma", 0.99),
            clip_epsilon=config.get("clip_epsilon", 0.2),
            n_epochs=config.get("n_epochs", 10),
            batch_size=config.get("batch_size", 64)
        )
    elif model_name.lower() == "a2c":
        return A2CAgent(
            state_dim=state_dim,
            action_dim=2,
            hidden_sizes=tuple(config.get("hidden_sizes", [256, 256, 128])),
            lr=config.get("learning_rate", 7e-4),
            gamma=config.get("gamma", 0.99),
            n_steps=config.get("n_steps", 5)
        )
    else:
        raise ValueError(f"Unknown model: {model_name}")


def evaluate_agent(agent, X: np.ndarray, y: np.ndarray) -> dict:
    """Evaluate agent on dataset."""
    y_pred = agent.predict(X)
    y_proba = agent.predict_proba(X)[:, 1]
    
    return compute_metrics(y, y_pred, y_proba)


def train_dqn(agent, env, config: dict, val_data: tuple, output_dir: Path):
    """Train DQN agent."""
    episodes = config.get("episodes", 500)
    eval_freq = config.get("eval_freq", 10)
    
    X_val, y_val = val_data
    best_f1 = 0
    history = {"episode": [], "reward": [], "val_f1": [], "val_accuracy": []}
    
    for episode in tqdm(range(episodes), desc="Training DQN"):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            action = agent.select_action(state, training=True)
            next_state, reward, done, _, _ = env.step(action)
            
            agent.store_transition(state, action, reward, next_state, done)
            agent.train_step()
            
            state = next_state
            episode_reward += reward
        
        # Evaluate
        if (episode + 1) % eval_freq == 0:
            metrics = evaluate_agent(agent, X_val, y_val)
            
            history["episode"].append(episode + 1)
            history["reward"].append(episode_reward)
            history["val_f1"].append(metrics["f1"])
            history["val_accuracy"].append(metrics["accuracy"])
            
            if metrics["f1"] > best_f1:
                best_f1 = metrics["f1"]
                agent.save(output_dir / "best_model.pt")
            
            tqdm.write(f"Episode {episode+1}: Reward={episode_reward:.1f}, "
                      f"Val F1={metrics['f1']:.4f}, Val Acc={metrics['accuracy']:.4f}")
    
    return history


def train_ppo(agent, env, config: dict, val_data: tuple, output_dir: Path):
    """Train PPO agent."""
    episodes = config.get("episodes", 500)
    rollout_steps = config.get("rollout_steps", 2048)
    eval_freq = config.get("eval_freq", 10)
    
    X_val, y_val = val_data
    best_f1 = 0
    history = {"episode": [], "reward": [], "val_f1": [], "val_accuracy": []}
    
    for episode in tqdm(range(episodes), desc="Training PPO"):
        state, _ = env.reset()
        episode_reward = 0
        steps = 0
        done = False
        
        while not done:
            action, log_prob, value = agent.select_action(state, training=True)
            next_state, reward, done, _, _ = env.step(action)
            
            agent.store_transition(state, action, reward, value, log_prob, done)
            
            state = next_state
            episode_reward += reward
            steps += 1
            
            # Update every rollout_steps
            if steps % rollout_steps == 0 and not done:
                _, _, last_value = agent.select_action(state, training=False)
                agent.train(last_value=last_value)
        
        # Final update
        agent.train(last_value=0.0)
        
        # Evaluate
        if (episode + 1) % eval_freq == 0:
            metrics = evaluate_agent(agent, X_val, y_val)
            
            history["episode"].append(episode + 1)
            history["reward"].append(episode_reward)
            history["val_f1"].append(metrics["f1"])
            history["val_accuracy"].append(metrics["accuracy"])
            
            if metrics["f1"] > best_f1:
                best_f1 = metrics["f1"]
                agent.save(output_dir / "best_model.pt")
            
            tqdm.write(f"Episode {episode+1}: Reward={episode_reward:.1f}, "
                      f"Val F1={metrics['f1']:.4f}, Val Acc={metrics['accuracy']:.4f}")
    
    return history


def train_a2c(agent, env, config: dict, val_data: tuple, output_dir: Path):
    """Train A2C agent."""
    episodes = config.get("episodes", 500)
    eval_freq = config.get("eval_freq", 10)
    
    X_val, y_val = val_data
    best_f1 = 0
    history = {"episode": [], "reward": [], "val_f1": [], "val_accuracy": []}
    
    for episode in tqdm(range(episodes), desc="Training A2C"):
        state, _ = env.reset()
        episode_reward = 0
        done = False
        
        while not done:
            action, log_prob, value = agent.select_action(state, training=True)
            next_state, reward, done, _, _ = env.step(action)
            
            agent.store_transition(state, action, reward, value, log_prob, done)
            
            # A2C updates every n_steps
            if not done:
                _, _, next_value = agent.select_action(next_state, training=False)
                agent.train(next_value=next_value)
            
            state = next_state
            episode_reward += reward
        
        # Final update
        agent.train(next_value=0.0)
        
        # Evaluate
        if (episode + 1) % eval_freq == 0:
            metrics = evaluate_agent(agent, X_val, y_val)
            
            history["episode"].append(episode + 1)
            history["reward"].append(episode_reward)
            history["val_f1"].append(metrics["f1"])
            history["val_accuracy"].append(metrics["accuracy"])
            
            if metrics["f1"] > best_f1:
                best_f1 = metrics["f1"]
                agent.save(output_dir / "best_model.pt")
            
            tqdm.write(f"Episode {episode+1}: Reward={episode_reward:.1f}, "
                      f"Val F1={metrics['f1']:.4f}, Val Acc={metrics['accuracy']:.4f}")
    
    return history


def main():
    parser = argparse.ArgumentParser(description="Train DRL model for zero-day detection")
    parser.add_argument("--config", type=str, help="Path to config YAML file")
    parser.add_argument("--model", type=str, default="ppo", choices=["dqn", "ppo", "a2c"])
    parser.add_argument("--dataset", type=str, default="cicids2017")
    parser.add_argument("--lambda_fn", type=float, default=10.0, help="False negative penalty")
    parser.add_argument("--episodes", type=int, default=500)
    parser.add_argument("--output_dir", type=str, default="logs")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    
    # Load config
    if args.config:
        with open(args.config, "r") as f:
            config = yaml.safe_load(f)
    else:
        config = {
            "model": {"name": args.model},
            "data": {"dataset": args.dataset},
            "env": {"reward": {"fn_penalty": -args.lambda_fn}},
            "train": {"episodes": args.episodes}
        }
    
    # Set seed
    np.random.seed(args.seed)
    
    # Create output directory
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_name = config.get("model", {}).get("name", args.model)
    dataset = config.get("data", {}).get("dataset", args.dataset)
    output_dir = Path(args.output_dir) / f"{model_name}_{dataset}_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save config
    with open(output_dir / "config.yaml", "w") as f:
        yaml.dump(config, f)
    
    print(f"Output directory: {output_dir}")
    
    # Load data
    print(f"Loading {dataset} dataset...")
    data = load_data(dataset)
    X_train, y_train = data["train"]
    X_val, y_val = data["val"]
    X_test, y_test = data["test"]
    
    print(f"Train: {len(X_train)}, Val: {len(X_val)}, Test (ZD): {len(X_test)}")
    
    # Create environment
    lambda_fn = abs(config.get("env", {}).get("reward", {}).get("fn_penalty", -args.lambda_fn))
    env = create_env(X_train, y_train, lambda_fn=lambda_fn, seed=args.seed)
    
    # Create agent
    train_config = config.get("train", {})
    agent = create_agent(model_name, state_dim=X_train.shape[1], config=train_config)
    
    print(f"Training {model_name.upper()} with λ={lambda_fn}...")
    
    # Train
    if model_name.lower() == "dqn":
        history = train_dqn(agent, env, train_config, (X_val, y_val), output_dir)
    elif model_name.lower() == "ppo":
        history = train_ppo(agent, env, train_config, (X_val, y_val), output_dir)
    else:
        history = train_a2c(agent, env, train_config, (X_val, y_val), output_dir)
    
    # Save history
    with open(output_dir / "history.json", "w") as f:
        json.dump(history, f, indent=2)
    
    # Final evaluation on test set (zero-day)
    agent.load(output_dir / "best_model.pt")
    test_metrics = evaluate_agent(agent, X_test, y_test)
    
    print("\n" + "="*50)
    print("ZERO-DAY TEST RESULTS")
    print("="*50)
    for k, v in test_metrics.items():
        print(f"{k}: {v:.4f}")
    
    # Save test results
    with open(output_dir / "test_results.json", "w") as f:
        json.dump(test_metrics, f, indent=2)
    
    print(f"\nResults saved to {output_dir}")


if __name__ == "__main__":
    main()
