"""
Advantage Actor-Critic (A2C) for Zero-Day Attack Detection

Implementation based on:
- Mnih et al. (2016) "Asynchronous Methods for Deep Reinforcement Learning"
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from typing import Tuple, Dict, List, Optional


class A2CNetwork(nn.Module):
    """Actor-Critic network for A2C."""
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_sizes: Tuple[int, ...] = (256, 256, 128)
    ):
        super().__init__()
        
        # Shared feature extractor
        layers = []
        prev_size = state_dim
        for hidden_size in hidden_sizes[:-1]:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.ReLU(),
            ])
            prev_size = hidden_size
        
        self.shared = nn.Sequential(*layers)
        
        # Actor head
        self.actor = nn.Sequential(
            nn.Linear(prev_size, hidden_sizes[-1]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[-1], action_dim),
            nn.Softmax(dim=-1)
        )
        
        # Critic head
        self.critic = nn.Sequential(
            nn.Linear(prev_size, hidden_sizes[-1]),
            nn.ReLU(),
            nn.Linear(hidden_sizes[-1], 1)
        )
        
        self._init_weights()
    
    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
    
    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        features = self.shared(x)
        action_probs = self.actor(features)
        value = self.critic(features)
        return action_probs, value


class A2CAgent:
    """
    A2C Agent for zero-day attack detection.
    
    Parameters
    ----------
    state_dim : int
        Dimension of state space
    action_dim : int
        Number of actions
    hidden_sizes : tuple
        Hidden layer sizes
    lr : float
        Learning rate
    gamma : float
        Discount factor
    value_coef : float
        Value loss coefficient
    entropy_coef : float
        Entropy bonus coefficient
    max_grad_norm : float
        Gradient clipping threshold
    n_steps : int
        Number of steps before update
    device : str
        'cuda' or 'cpu'
    """
    
    def __init__(
        self,
        state_dim: int,
        action_dim: int = 2,
        hidden_sizes: Tuple[int, ...] = (256, 256, 128),
        lr: float = 7e-4,
        gamma: float = 0.99,
        value_coef: float = 0.5,
        entropy_coef: float = 0.01,
        max_grad_norm: float = 0.5,
        n_steps: int = 5,
        device: str = "cuda" if torch.cuda.is_available() else "cpu"
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.max_grad_norm = max_grad_norm
        self.n_steps = n_steps
        self.device = torch.device(device)
        
        # Network
        self.network = A2CNetwork(state_dim, action_dim, hidden_sizes).to(self.device)
        self.optimizer = optim.RMSprop(self.network.parameters(), lr=lr, eps=1e-5, alpha=0.99)
        
        # Buffers
        self.states = []
        self.actions = []
        self.rewards = []
        self.values = []
        self.log_probs = []
        self.dones = []
        
        # Training stats
        self.training_stats = []
    
    def select_action(self, state: np.ndarray, training: bool = True) -> Tuple[int, float, float]:
        """Select action and return action, log_prob, value."""
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_probs, value = self.network(state_tensor)
            
            if training:
                dist = torch.distributions.Categorical(action_probs)
                action = dist.sample()
                log_prob = dist.log_prob(action)
            else:
                action = action_probs.argmax(dim=1)
                log_prob = torch.log(action_probs.max())
        
        return action.item(), log_prob.item(), value.item()
    
    def store_transition(self, state, action, reward, value, log_prob, done):
        """Store transition."""
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.values.append(value)
        self.log_probs.append(log_prob)
        self.dones.append(done)
    
    def train(self, next_value: float = 0.0) -> Optional[Dict[str, float]]:
        """Perform A2C update if enough steps collected."""
        if len(self.states) < self.n_steps:
            return None
        
        # Compute returns
        returns = []
        R = next_value
        for reward, done in zip(reversed(self.rewards), reversed(self.dones)):
            R = reward + self.gamma * R * (1 - done)
            returns.insert(0, R)
        
        # Convert to tensors
        states = torch.FloatTensor(np.array(self.states)).to(self.device)
        actions = torch.LongTensor(self.actions).to(self.device)
        returns = torch.FloatTensor(returns).to(self.device)
        old_log_probs = torch.FloatTensor(self.log_probs).to(self.device)
        old_values = torch.FloatTensor(self.values).to(self.device)
        
        # Forward pass
        action_probs, values = self.network(states)
        values = values.squeeze()
        
        dist = torch.distributions.Categorical(action_probs)
        log_probs = dist.log_prob(actions)
        entropy = dist.entropy().mean()
        
        # Compute advantages
        advantages = returns - values.detach()
        
        # Policy loss
        policy_loss = -(log_probs * advantages).mean()
        
        # Value loss
        value_loss = nn.MSELoss()(values, returns)
        
        # Total loss
        loss = policy_loss + self.value_coef * value_loss - self.entropy_coef * entropy
        
        # Optimize
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.network.parameters(), self.max_grad_norm)
        self.optimizer.step()
        
        # Clear buffers
        self.states = []
        self.actions = []
        self.rewards = []
        self.values = []
        self.log_probs = []
        self.dones = []
        
        stats = {
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "entropy": entropy.item()
        }
        self.training_stats.append(stats)
        
        return stats
    
    def save(self, path: str):
        """Save model checkpoint."""
        torch.save({
            'network_state_dict': self.network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)
    
    def load(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path, map_location=self.device)
        self.network.load_state_dict(checkpoint['network_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    
    def predict(self, states: np.ndarray) -> np.ndarray:
        """Batch prediction for evaluation."""
        self.network.eval()
        with torch.no_grad():
            states_tensor = torch.FloatTensor(states).to(self.device)
            action_probs, _ = self.network(states_tensor)
            actions = action_probs.argmax(dim=1).cpu().numpy()
        self.network.train()
        return actions
    
    def predict_proba(self, states: np.ndarray) -> np.ndarray:
        """Get action probabilities."""
        self.network.eval()
        with torch.no_grad():
            states_tensor = torch.FloatTensor(states).to(self.device)
            action_probs, _ = self.network(states_tensor)
            probs = action_probs.cpu().numpy()
        self.network.train()
        return probs


if __name__ == "__main__":
    # Quick test
    agent = A2CAgent(state_dim=30, action_dim=2, n_steps=5)
    
    # Simulate rollout
    for _ in range(20):
        state = np.random.rand(30).astype(np.float32)
        action, log_prob, value = agent.select_action(state)
        reward = np.random.choice([-10, -1, 1])
        done = np.random.random() < 0.1
        
        agent.store_transition(state, action, reward, value, log_prob, done)
        
        stats = agent.train(next_value=0.0)
        if stats:
            print(f"Training stats: {stats}")
