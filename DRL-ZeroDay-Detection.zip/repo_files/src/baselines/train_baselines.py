"""
Training Script for Baseline Models

Trains and evaluates all baseline methods:
- Traditional ML: SVM, Random Forest, XGBoost
- Deep Learning: CNN, LSTM, Autoencoder
- Modern: Deep SVDD, VAE, ContrastiveNet, Transformer-AE

Usage:
    python -m src.baselines.train_baselines --dataset cicids2017 --output_dir results/baselines
"""

import argparse
import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime
import json
import time
import warnings
warnings.filterwarnings('ignore')

# Traditional ML
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier

# Deep Learning
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

from src.evaluation.metrics import compute_metrics, print_metrics

# ==================== Traditional ML Baselines ====================

def train_svm(X_train, y_train, X_val, y_val):
    """Train SVM with optimized hyperparameters."""
    print("Training SVM...")
    start = time.time()
    
    model = SVC(
        kernel='rbf',
        C=100,
        gamma='scale',
        probability=True,
        class_weight='balanced',
        random_state=42
    )
    model.fit(X_train, y_train)
    
    train_time = time.time() - start
    
    # Evaluate
    start = time.time()
    y_pred = model.predict(X_val)
    y_proba = model.predict_proba(X_val)[:, 1]
    inference_time = (time.time() - start) / len(X_val) * 1000  # ms per sample
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


def train_random_forest(X_train, y_train, X_val, y_val):
    """Train Random Forest with optimized hyperparameters."""
    print("Training Random Forest...")
    start = time.time()
    
    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=30,
        min_samples_split=5,
        min_samples_leaf=2,
        class_weight='balanced',
        n_jobs=-1,
        random_state=42
    )
    model.fit(X_train, y_train)
    
    train_time = time.time() - start
    
    # Evaluate
    start = time.time()
    y_pred = model.predict(X_val)
    y_proba = model.predict_proba(X_val)[:, 1]
    inference_time = (time.time() - start) / len(X_val) * 1000
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


def train_xgboost(X_train, y_train, X_val, y_val):
    """Train XGBoost with optimized hyperparameters."""
    print("Training XGBoost...")
    start = time.time()
    
    # Compute scale_pos_weight for imbalance
    scale_pos = np.sum(y_train == 0) / np.sum(y_train == 1)
    
    model = XGBClassifier(
        n_estimators=300,
        max_depth=7,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=scale_pos,
        use_label_encoder=False,
        eval_metric='logloss',
        random_state=42
    )
    model.fit(X_train, y_train)
    
    train_time = time.time() - start
    
    # Evaluate
    start = time.time()
    y_pred = model.predict(X_val)
    y_proba = model.predict_proba(X_val)[:, 1]
    inference_time = (time.time() - start) / len(X_val) * 1000
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


# ==================== Deep Learning Baselines ====================

class CNNClassifier(nn.Module):
    """1D CNN for tabular data."""
    def __init__(self, input_dim, num_classes=2):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 64, kernel_size=3, padding=1)
        self.conv2 = nn.Conv1d(64, 128, kernel_size=3, padding=1)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.fc = nn.Sequential(
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes)
        )
    
    def forward(self, x):
        x = x.unsqueeze(1)  # Add channel dim
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = self.pool(x).squeeze(-1)
        return self.fc(x)


class LSTMClassifier(nn.Module):
    """LSTM for sequential/tabular data."""
    def __init__(self, input_dim, num_classes=2):
        super().__init__()
        self.lstm1 = nn.LSTM(input_dim, 128, batch_first=True, dropout=0.3)
        self.lstm2 = nn.LSTM(128, 64, batch_first=True, dropout=0.2)
        self.fc = nn.Linear(64, num_classes)
    
    def forward(self, x):
        x = x.unsqueeze(1)  # Add seq dim
        x, _ = self.lstm1(x)
        x, _ = self.lstm2(x)
        x = x[:, -1, :]  # Last timestep
        return self.fc(x)


class Autoencoder(nn.Module):
    """Autoencoder for anomaly detection."""
    def __init__(self, input_dim, encoding_dim=32):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, encoding_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(encoding_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, input_dim)
        )
    
    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded


def train_deep_model(model, train_loader, val_loader, epochs=100, lr=0.001, patience=10, device='cuda'):
    """Generic training loop for deep learning models."""
    model = model.to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    criterion = nn.CrossEntropyLoss()
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=5, factor=0.5)
    
    best_val_loss = float('inf')
    patience_counter = 0
    best_state = None
    
    for epoch in range(epochs):
        # Train
        model.train()
        train_loss = 0
        for X_batch, y_batch in train_loader:
            X_batch, y_batch = X_batch.to(device), y_batch.to(device)
            
            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            
            train_loss += loss.item()
        
        # Validate
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for X_batch, y_batch in val_loader:
                X_batch, y_batch = X_batch.to(device), y_batch.to(device)
                outputs = model(X_batch)
                val_loss += criterion(outputs, y_batch).item()
        
        val_loss /= len(val_loader)
        scheduler.step(val_loss)
        
        # Early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = model.state_dict().copy()
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= patience:
                print(f"Early stopping at epoch {epoch+1}")
                break
    
    model.load_state_dict(best_state)
    return model


def train_cnn(X_train, y_train, X_val, y_val, device='cuda'):
    """Train CNN classifier."""
    print("Training CNN...")
    start = time.time()
    
    # Create data loaders
    train_dataset = TensorDataset(
        torch.FloatTensor(X_train),
        torch.LongTensor(y_train)
    )
    val_dataset = TensorDataset(
        torch.FloatTensor(X_val),
        torch.LongTensor(y_val)
    )
    
    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=256)
    
    model = CNNClassifier(X_train.shape[1])
    model = train_deep_model(model, train_loader, val_loader, device=device)
    
    train_time = time.time() - start
    
    # Evaluate
    model.eval()
    start = time.time()
    with torch.no_grad():
        X_val_tensor = torch.FloatTensor(X_val).to(device)
        outputs = model(X_val_tensor)
        y_proba = torch.softmax(outputs, dim=1)[:, 1].cpu().numpy()
        y_pred = outputs.argmax(dim=1).cpu().numpy()
    inference_time = (time.time() - start) / len(X_val) * 1000
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


def train_lstm(X_train, y_train, X_val, y_val, device='cuda'):
    """Train LSTM classifier."""
    print("Training LSTM...")
    start = time.time()
    
    train_dataset = TensorDataset(
        torch.FloatTensor(X_train),
        torch.LongTensor(y_train)
    )
    val_dataset = TensorDataset(
        torch.FloatTensor(X_val),
        torch.LongTensor(y_val)
    )
    
    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=256)
    
    model = LSTMClassifier(X_train.shape[1])
    model = train_deep_model(model, train_loader, val_loader, device=device)
    
    train_time = time.time() - start
    
    # Evaluate
    model.eval()
    start = time.time()
    with torch.no_grad():
        X_val_tensor = torch.FloatTensor(X_val).to(device)
        outputs = model(X_val_tensor)
        y_proba = torch.softmax(outputs, dim=1)[:, 1].cpu().numpy()
        y_pred = outputs.argmax(dim=1).cpu().numpy()
    inference_time = (time.time() - start) / len(X_val) * 1000
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


def train_autoencoder(X_train, y_train, X_val, y_val, device='cuda', threshold_percentile=95):
    """Train Autoencoder for anomaly detection."""
    print("Training Autoencoder...")
    start = time.time()
    
    # Train only on normal samples
    X_train_normal = X_train[y_train == 0]
    
    train_dataset = TensorDataset(torch.FloatTensor(X_train_normal))
    train_loader = DataLoader(train_dataset, batch_size=256, shuffle=True)
    
    model = Autoencoder(X_train.shape[1], encoding_dim=32).to(device)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.MSELoss()
    
    for epoch in range(100):
        model.train()
        for (X_batch,) in train_loader:
            X_batch = X_batch.to(device)
            optimizer.zero_grad()
            reconstructed = model(X_batch)
            loss = criterion(reconstructed, X_batch)
            loss.backward()
            optimizer.step()
    
    train_time = time.time() - start
    
    # Compute reconstruction errors on training data to set threshold
    model.eval()
    with torch.no_grad():
        X_train_tensor = torch.FloatTensor(X_train_normal).to(device)
        reconstructed = model(X_train_tensor)
        train_errors = ((X_train_tensor - reconstructed) ** 2).mean(dim=1).cpu().numpy()
    
    threshold = np.percentile(train_errors, threshold_percentile)
    
    # Evaluate
    start = time.time()
    with torch.no_grad():
        X_val_tensor = torch.FloatTensor(X_val).to(device)
        reconstructed = model(X_val_tensor)
        val_errors = ((X_val_tensor - reconstructed) ** 2).mean(dim=1).cpu().numpy()
    
    y_pred = (val_errors > threshold).astype(int)
    y_proba = (val_errors - val_errors.min()) / (val_errors.max() - val_errors.min())
    inference_time = (time.time() - start) / len(X_val) * 1000
    
    metrics = compute_metrics(y_val, y_pred, y_proba)
    metrics['train_time'] = train_time
    metrics['inference_ms'] = inference_time
    
    return model, metrics


# ==================== Main ====================

def load_data(dataset: str, data_dir: str = "data/splits"):
    """Load dataset splits."""
    path = Path(data_dir) / dataset
    
    train_df = pd.read_csv(path / "train.csv")
    val_df = pd.read_csv(path / "val.csv")
    test_df = pd.read_csv(path / "test_zero_day.csv")
    
    X_train = train_df.iloc[:, :-1].values.astype(np.float32)
    y_train = train_df.iloc[:, -1].values.astype(np.int32)
    
    X_val = val_df.iloc[:, :-1].values.astype(np.float32)
    y_val = val_df.iloc[:, -1].values.astype(np.int32)
    
    X_test = test_df.iloc[:, :-1].values.astype(np.float32)
    y_test = test_df.iloc[:, -1].values.astype(np.int32)
    
    return (X_train, y_train), (X_val, y_val), (X_test, y_test)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=str, default="cicids2017")
    parser.add_argument("--output_dir", type=str, default="results/baselines")
    parser.add_argument("--device", type=str, default="cuda" if torch.cuda.is_available() else "cpu")
    args = parser.parse_args()
    
    # Create output directory
    output_dir = Path(args.output_dir) / args.dataset
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load data
    print(f"Loading {args.dataset}...")
    (X_train, y_train), (X_val, y_val), (X_test, y_test) = load_data(args.dataset)
    print(f"Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")
    
    results = {}
    
    # Train all baselines
    baselines = [
        ("SVM", train_svm),
        ("RandomForest", train_random_forest),
        ("XGBoost", train_xgboost),
        ("CNN", lambda *args: train_cnn(*args, device=args.device)),
        ("LSTM", lambda *args: train_lstm(*args, device=args.device)),
        ("Autoencoder", lambda *args: train_autoencoder(*args, device=args.device)),
    ]
    
    for name, train_fn in baselines:
        try:
            model, val_metrics = train_fn(X_train, y_train, X_val, y_val)
            
            # Test on zero-day data
            if hasattr(model, 'predict'):
                y_pred = model.predict(X_test)
                y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
            else:
                # PyTorch model
                model.eval()
                with torch.no_grad():
                    X_test_tensor = torch.FloatTensor(X_test).to(args.device)
                    outputs = model(X_test_tensor)
                    if outputs.shape[1] == 2:
                        y_pred = outputs.argmax(dim=1).cpu().numpy()
                        y_proba = torch.softmax(outputs, dim=1)[:, 1].cpu().numpy()
                    else:
                        # Autoencoder
                        errors = ((X_test_tensor - outputs) ** 2).mean(dim=1).cpu().numpy()
                        threshold = np.percentile(errors, 95)
                        y_pred = (errors > threshold).astype(int)
                        y_proba = errors
            
            test_metrics = compute_metrics(y_test, y_pred, y_proba)
            
            results[name] = {
                "val": val_metrics,
                "test_zero_day": test_metrics
            }
            
            print(f"\n{name} - Zero-Day Test Results:")
            print(f"  Accuracy: {test_metrics['accuracy']:.4f}")
            print(f"  F1: {test_metrics['f1']:.4f}")
            print(f"  Zero-Day Rate: {test_metrics['zero_day_rate']:.4f}")
            
        except Exception as e:
            print(f"Error training {name}: {e}")
            continue
    
    # Save results
    with open(output_dir / "results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to {output_dir}")


if __name__ == "__main__":
    main()
