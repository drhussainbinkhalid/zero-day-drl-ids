"""
Evaluation Metrics for Zero-Day Attack Detection

Provides consistent metric computation across all experiments.
"""

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    roc_auc_score,
    confusion_matrix,
    classification_report
)
from typing import Dict, Optional, Tuple


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_score: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Compute comprehensive evaluation metrics.
    
    Parameters
    ----------
    y_true : np.ndarray
        True labels (0 = normal, 1 = attack)
    y_pred : np.ndarray
        Predicted labels
    y_score : np.ndarray, optional
        Prediction scores/probabilities for positive class
        
    Returns
    -------
    dict
        Dictionary containing all metrics
    """
    # Basic metrics
    accuracy = accuracy_score(y_true, y_pred)
    precision, recall, f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="binary", pos_label=1, zero_division=0
    )
    
    # Confusion matrix
    cm = confusion_matrix(y_true, y_pred)
    tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
    
    # Derived metrics
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0  # False Positive Rate
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0  # False Negative Rate
    
    # Zero-day detection rate = Recall on attack class
    zero_day_rate = recall
    
    metrics = {
        "accuracy": float(accuracy),
        "precision": float(precision),
        "recall": float(recall),
        "f1": float(f1),
        "zero_day_rate": float(zero_day_rate),
        "fpr": float(fpr),
        "fnr": float(fnr),
        "tp": int(tp),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn)
    }
    
    # AUROC if scores available
    if y_score is not None and len(np.unique(y_true)) > 1:
        try:
            auroc = roc_auc_score(y_true, y_score)
            metrics["auroc"] = float(auroc)
        except ValueError:
            metrics["auroc"] = 0.0
    
    return metrics


def compute_metrics_multiclass(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Optional[list] = None
) -> Dict:
    """
    Compute metrics for multi-class classification.
    
    Parameters
    ----------
    y_true : np.ndarray
        True labels
    y_pred : np.ndarray
        Predicted labels
    class_names : list, optional
        Names for each class
        
    Returns
    -------
    dict
        Dictionary containing per-class and overall metrics
    """
    accuracy = accuracy_score(y_true, y_pred)
    
    # Per-class metrics
    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, average=None, zero_division=0
    )
    
    # Macro and weighted averages
    macro_precision, macro_recall, macro_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="macro", zero_division=0
    )
    weighted_precision, weighted_recall, weighted_f1, _ = precision_recall_fscore_support(
        y_true, y_pred, average="weighted", zero_division=0
    )
    
    results = {
        "accuracy": float(accuracy),
        "macro": {
            "precision": float(macro_precision),
            "recall": float(macro_recall),
            "f1": float(macro_f1)
        },
        "weighted": {
            "precision": float(weighted_precision),
            "recall": float(weighted_recall),
            "f1": float(weighted_f1)
        },
        "per_class": {}
    }
    
    n_classes = len(precision)
    for i in range(n_classes):
        class_name = class_names[i] if class_names else str(i)
        results["per_class"][class_name] = {
            "precision": float(precision[i]),
            "recall": float(recall[i]),
            "f1": float(f1[i]),
            "support": int(support[i])
        }
    
    return results


def print_metrics(metrics: Dict[str, float], title: str = "Evaluation Results"):
    """Pretty print metrics."""
    print("\n" + "=" * 50)
    print(title)
    print("=" * 50)
    
    # Main metrics
    main_metrics = ["accuracy", "precision", "recall", "f1", "zero_day_rate", "auroc"]
    for m in main_metrics:
        if m in metrics:
            print(f"{m:20s}: {metrics[m]:.4f}")
    
    print("-" * 50)
    
    # Secondary metrics
    secondary = ["fpr", "fnr"]
    for m in secondary:
        if m in metrics:
            print(f"{m:20s}: {metrics[m]:.4f}")
    
    print("-" * 50)
    
    # Confusion matrix components
    if all(k in metrics for k in ["tp", "tn", "fp", "fn"]):
        print(f"{'TP':20s}: {metrics['tp']}")
        print(f"{'TN':20s}: {metrics['tn']}")
        print(f"{'FP':20s}: {metrics['fp']}")
        print(f"{'FN':20s}: {metrics['fn']}")
    
    print("=" * 50 + "\n")


def compare_models(results: Dict[str, Dict], metric: str = "f1") -> str:
    """
    Compare multiple models and return best model name.
    
    Parameters
    ----------
    results : dict
        Dictionary mapping model names to their metrics
    metric : str
        Metric to compare on
        
    Returns
    -------
    str
        Name of best model
    """
    best_model = None
    best_value = -1
    
    for model_name, metrics in results.items():
        value = metrics.get(metric, 0)
        if value > best_value:
            best_value = value
            best_model = model_name
    
    return best_model


if __name__ == "__main__":
    # Example usage
    np.random.seed(42)
    
    y_true = np.random.randint(0, 2, 1000)
    y_pred = np.random.randint(0, 2, 1000)
    y_score = np.random.rand(1000)
    
    metrics = compute_metrics(y_true, y_pred, y_score)
    print_metrics(metrics, "Example Results")
