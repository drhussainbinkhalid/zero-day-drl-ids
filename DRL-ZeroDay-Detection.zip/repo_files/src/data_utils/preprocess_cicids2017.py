"""
CICIDS2017 Dataset Preprocessing

Implements:
1. Data cleaning and normalization
2. Feature selection (PCA + Information Gain)
3. Attack-family-aware train/val/test splitting

Attack Family Partitioning:
- Train/Val: DoS (Hulk, GoldenEye), DDoS, Port Scan, Brute Force
- Test (Zero-Day): Web Attacks (XSS, SQL Injection), Botnet, Infiltration, Heartbleed
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler, LabelEncoder
from sklearn.decomposition import PCA
from sklearn.feature_selection import mutual_info_classif
import json
import warnings
warnings.filterwarnings('ignore')


# Attack family definitions for CICIDS2017
TRAIN_ATTACKS = [
    'DoS Hulk', 'DoS GoldenEye', 'DoS slowloris', 'DoS Slowhttptest',
    'DDoS',
    'PortScan',
    'FTP-Patator', 'SSH-Patator'
]

TEST_ATTACKS = [  # Zero-day simulation
    'Web Attack – Brute Force', 'Web Attack – XSS', 'Web Attack – Sql Injection',
    'Bot',
    'Infiltration',
    'Heartbleed'
]


def load_raw_data(raw_dir: Path) -> pd.DataFrame:
    """Load and concatenate all CICIDS2017 CSV files."""
    csv_files = list(raw_dir.glob("*.csv"))
    
    if not csv_files:
        raise FileNotFoundError(f"No CSV files found in {raw_dir}")
    
    print(f"Loading {len(csv_files)} files...")
    
    dfs = []
    for f in csv_files:
        df = pd.read_csv(f, low_memory=False)
        df.columns = df.columns.str.strip()  # Remove whitespace
        dfs.append(df)
    
    data = pd.concat(dfs, ignore_index=True)
    print(f"Total samples: {len(data)}")
    
    return data


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Clean dataset: handle missing values, infinities, duplicates."""
    print("Cleaning data...")
    
    # Remove whitespace from label column
    if 'Label' in df.columns:
        df['Label'] = df['Label'].str.strip()
    elif ' Label' in df.columns:
        df['Label'] = df[' Label'].str.strip()
        df = df.drop(' Label', axis=1)
    
    # Replace infinities with NaN
    df = df.replace([np.inf, -np.inf], np.nan)
    
    # Drop rows with NaN
    initial_len = len(df)
    df = df.dropna()
    print(f"Removed {initial_len - len(df)} rows with missing values")
    
    # Remove duplicates
    initial_len = len(df)
    df = df.drop_duplicates()
    print(f"Removed {initial_len - len(df)} duplicate rows")
    
    return df


def select_features(X: np.ndarray, y: np.ndarray, n_features: int = 30) -> tuple:
    """
    Feature selection using PCA + Information Gain.
    
    1. Apply PCA to reduce to 50 components
    2. Rank by Information Gain
    3. Select top n_features
    """
    print(f"Selecting top {n_features} features...")
    
    # PCA reduction
    pca = PCA(n_components=min(50, X.shape[1]))
    X_pca = pca.fit_transform(X)
    
    # Information Gain ranking
    mi_scores = mutual_info_classif(X_pca, y, random_state=42)
    top_indices = np.argsort(mi_scores)[-n_features:]
    
    X_selected = X_pca[:, top_indices]
    
    return X_selected, pca, top_indices


def split_by_attack_family(
    df: pd.DataFrame,
    train_attacks: list,
    test_attacks: list,
    train_ratio: float = 0.75  # Of the train attacks, 75% train, 25% val
) -> tuple:
    """
    Split data by attack family for zero-day simulation.
    
    - Training: normal traffic + train_attacks
    - Validation: normal traffic + train_attacks (different samples)
    - Test (Zero-Day): normal traffic + test_attacks (never seen)
    """
    print("Splitting by attack family...")
    
    # Separate normal and attack traffic
    normal_mask = df['Label'] == 'BENIGN'
    normal_df = df[normal_mask]
    
    # Split normal traffic temporally (earlier for train, later for test)
    n_normal = len(normal_df)
    normal_train = normal_df.iloc[:int(n_normal * 0.6)]
    normal_val = normal_df.iloc[int(n_normal * 0.6):int(n_normal * 0.8)]
    normal_test = normal_df.iloc[int(n_normal * 0.8):]
    
    # Training attacks
    train_attack_mask = df['Label'].isin(train_attacks)
    train_attack_df = df[train_attack_mask]
    
    n_train_attacks = len(train_attack_df)
    train_attacks_train = train_attack_df.iloc[:int(n_train_attacks * train_ratio)]
    train_attacks_val = train_attack_df.iloc[int(n_train_attacks * train_ratio):]
    
    # Test attacks (zero-day)
    test_attack_mask = df['Label'].isin(test_attacks)
    test_attack_df = df[test_attack_mask]
    
    # Combine
    train_df = pd.concat([normal_train, train_attacks_train])
    val_df = pd.concat([normal_val, train_attacks_val])
    test_df = pd.concat([normal_test, test_attack_df])
    
    # Shuffle
    train_df = train_df.sample(frac=1, random_state=42).reset_index(drop=True)
    val_df = val_df.sample(frac=1, random_state=42).reset_index(drop=True)
    test_df = test_df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    print(f"Train: {len(train_df)} (Normal: {len(normal_train)}, Attack: {len(train_attacks_train)})")
    print(f"Val: {len(val_df)} (Normal: {len(normal_val)}, Attack: {len(train_attacks_val)})")
    print(f"Test (ZD): {len(test_df)} (Normal: {len(normal_test)}, Attack: {len(test_attack_df)})")
    
    return train_df, val_df, test_df


def preprocess_cicids2017(
    raw_dir: str = "data/raw/cicids2017",
    output_dir: str = "data/splits/cicids2017",
    n_features: int = 30
):
    """Main preprocessing pipeline for CICIDS2017."""
    raw_dir = Path(raw_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load and clean
    df = load_raw_data(raw_dir)
    df = clean_data(df)
    
    # Split by attack family
    train_df, val_df, test_df = split_by_attack_family(
        df, TRAIN_ATTACKS, TEST_ATTACKS
    )
    
    # Get feature columns (all except Label)
    feature_cols = [c for c in train_df.columns if c != 'Label']
    
    # Extract features and labels
    X_train = train_df[feature_cols].values.astype(np.float32)
    X_val = val_df[feature_cols].values.astype(np.float32)
    X_test = test_df[feature_cols].values.astype(np.float32)
    
    # Binary labels: 0 = normal, 1 = attack
    y_train = (train_df['Label'] != 'BENIGN').astype(int).values
    y_val = (val_df['Label'] != 'BENIGN').astype(int).values
    y_test = (test_df['Label'] != 'BENIGN').astype(int).values
    
    # Normalize
    print("Normalizing features...")
    scaler = MinMaxScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)
    
    # Feature selection
    X_train, pca, top_indices = select_features(X_train, y_train, n_features)
    X_val = pca.transform(X_val)[:, top_indices]
    X_test = pca.transform(X_test)[:, top_indices]
    
    # Create output DataFrames
    feature_names = [f"feature_{i}" for i in range(n_features)]
    
    train_out = pd.DataFrame(X_train, columns=feature_names)
    train_out['label'] = y_train
    
    val_out = pd.DataFrame(X_val, columns=feature_names)
    val_out['label'] = y_val
    
    test_out = pd.DataFrame(X_test, columns=feature_names)
    test_out['label'] = y_test
    
    # Save
    train_out.to_csv(output_dir / "train.csv", index=False)
    val_out.to_csv(output_dir / "val.csv", index=False)
    test_out.to_csv(output_dir / "test_zero_day.csv", index=False)
    
    # Save metadata
    metadata = {
        "dataset": "CICIDS2017",
        "n_features": n_features,
        "train_attacks": TRAIN_ATTACKS,
        "test_attacks": TEST_ATTACKS,
        "train_samples": len(train_out),
        "val_samples": len(val_out),
        "test_samples": len(test_out),
        "train_attack_ratio": float(y_train.mean()),
        "val_attack_ratio": float(y_val.mean()),
        "test_attack_ratio": float(y_test.mean())
    }
    
    with open(output_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2)
    
    print(f"\nSaved to {output_dir}")
    print(f"Train: {len(train_out)}, Val: {len(val_out)}, Test: {len(test_out)}")


if __name__ == "__main__":
    preprocess_cicids2017()
